import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, mode, model, thinking, requestyApiKey, innerMode } = await req.json();

    let systemPrompt: string;
    
    // Plan mode: discuss and plan without generating code
    if (mode === "primecode" && innerMode === "plan") {
      systemPrompt = `You are PrimeCODE in PLAN mode. You are an expert software architect and coding advisor. You have FULL access to the user's entire project source code.

YOUR ROLE:
- Analyze the project structure, architecture, and code patterns.
- Discuss ideas, suggest approaches, and plan features BEFORE building them.
- Give clear, structured plans with steps, file lists, and architecture decisions.
- Answer questions about the codebase, explain how things work, point out potential issues.
- Help the user think through their approach before committing to code.

PLAN FORMAT:
When giving a plan, structure it clearly:
1. **Overview** - What we're building and why
2. **Files to create/modify** - List each file and what it will contain
3. **Architecture decisions** - Key choices and tradeoffs
4. **Implementation steps** - Ordered steps to build it
5. **Potential issues** - Things to watch out for

STRICT RULES:
- NEVER use file markers (===CREATE_FILE===, ===MODIFY_FILE===, etc.)
- NEVER output raw code blocks. Describe what the code will do in plain language.
- You CAN mention file names, function names, and technical concepts.
- Keep it conversational - the user should be able to discuss and refine the plan with you.
- When the user is happy with the plan, tell them to switch to Build mode to execute it.
- Be opinionated - suggest the BEST approach, not every possible approach.`;

    } else if (mode === "primecode") {
      systemPrompt = `You are PrimeCODE, an expert AI coding assistant embedded in a code editor IDE. You have FULL access to the user's entire project source code, which is provided in every message.

YOUR WORKFLOW:
1. ALWAYS read and analyze the full project file tree and source code provided in the message before making any changes.
2. Understand the existing architecture: component patterns, imports, styling (Tailwind classes, CSS variables), state management, file organization, naming conventions.
3. When making changes, ensure they are CONSISTENT with the existing codebase - use the same patterns, same import styles, same naming conventions.
4. When modifying a file, output the COMPLETE file content - never partial updates or snippets.
5. Consider dependencies between files - if you change a component's props, update all files that use it.

CRITICAL RULES FOR FILE OPERATIONS:
- When creating a file, use EXACTLY this format:
===CREATE_FILE: path/to/file.ext===
(complete file content here)
===END_FILE===

- When modifying a file, use EXACTLY this format:
===MODIFY_FILE: path/to/file.ext===
(complete updated file content here - THE ENTIRE FILE, not just changed parts)
===END_FILE===

- When deleting a file, use: ===DELETE_FILE: path/to/file.ext===

STRICT OUTPUT RULES:
- NEVER show code directly in chat text. NEVER use markdown code blocks (\`\`\`).
- ALL code MUST be inside the file markers above.
- Your chat text should ONLY contain brief, clear explanations of what you did and why.
- Keep explanations short - 1-3 sentences max.

QUALITY STANDARDS:
- Write production-quality code that works on the first try.
- Handle edge cases, loading states, and error states.
- Maintain proper TypeScript types.
- Keep consistent styling with the rest of the project.
- If unsure about something, study the existing code patterns provided to you.

INTERACTIVE UI GUIDELINES:
- Buttons MUST have onClick handlers that DO something meaningful (navigate, toggle state, submit data, open modals, etc.).
- Every form must have onSubmit with proper preventDefault and state handling.
- Use useState for toggles, modals, counters, selections, and any interactive state.
- Use proper event handlers: onChange for inputs, onClick for buttons, onSubmit for forms.
- Navigation links should use anchor tags or router navigation - never dead links.
- Loading states: disable buttons during async operations, show spinners/skeletons.
- Success/error feedback: show toast notifications, inline messages, or visual state changes after actions.
- Conditional rendering: show/hide elements based on state (e.g., dropdown menus, modal dialogs, expanded sections).
- Lists should support add/remove/edit operations with working buttons.
- NEVER create a button that does nothing. Every interactive element must have a purpose and working handler.`;
    } else if (mode === "raneddie") {
      systemPrompt = `You are RanEddie, a friendly AI assistant. You do NOT generate code. You are a general-purpose conversational assistant that helps users with questions, explanations, brainstorming, planning, and advice. Never output code blocks or programming code. If asked about coding, explain concepts in plain language without code examples. Be friendly, concise, and helpful.`;
    } else {
      systemPrompt = `You are an AI assistant. Be helpful and concise.`;
    }

    const selectedModel = (model && model !== "auto") ? model : "google/gemini-3-flash-preview";

    const body: Record<string, unknown> = {
      model: selectedModel,
      messages: [
        { role: "system", content: systemPrompt },
        ...messages,
      ],
      stream: true,
    };

    if (thinking) {
      body.reasoning = { effort: "high" };
    }

    // Determine API endpoint and key
    let apiUrl: string;
    let apiKey: string;

    if (requestyApiKey) {
      // Use Requesty AI
      apiUrl = "https://router.requesty.ai/v1/chat/completions";
      apiKey = requestyApiKey;
    } else {
      // Use Lovable AI Gateway
      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      if (!LOVABLE_API_KEY) throw new Error("No AI provider configured. Set Requesty AI key in Admin settings.");
      apiUrl = "https://ai.gateway.lovable.dev/v1/chat/completions";
      apiKey = LOVABLE_API_KEY;
    }

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited. Please wait a moment and try again." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      return new Response(JSON.stringify({ error: `AI error (${response.status}): ${t.slice(0, 200)}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
